// // 
// "use client"
// import 'bpmn-js/dist/assets/diagram-js.css';
// import 'bpmn-js/dist/assets/bpmn-js.css';

// import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css';
// import '@bpmn-io/properties-panel/assets/properties-panel.css';

// import './style.css';

// import $ from 'jquery';
// import BpmnModeler from 'bpmn-js/lib/Modeler';

// import { debounce } from 'min-dash';

// import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule } from 'bpmn-js-properties-panel';

// // import diagramXML from './newDiagram.bpmn';


// var container = $('#js-drop-zone');

// var canvas = $('#js-canvas');

// var bpmnModeler = new BpmnModeler({
//   container: canvas,
//   propertiesPanel: {
//     parent: '#js-properties-panel'
//   },
//   additionalModules: [
//     BpmnPropertiesPanelModule,
//     BpmnPropertiesProviderModule
//   ]
// });
// container.removeClass('with-diagram');

// function createNewDiagram() {
//   openDiagram(diagramXML);
// }

// async function openDiagram(xml) {

//   try {

//     await bpmnModeler.importXML(xml);

//     container
//       .removeClass('with-error')
//       .addClass('with-diagram');
//   } catch (err) {

//     container
//       .removeClass('with-diagram')
//       .addClass('with-error');

//     container.find('.error pre').text(err.message);

//     console.error(err);
//   }
// }

// function registerFileDrop(container, callback) {

//   function handleFileSelect(e) {
//     e.stopPropagation();
//     e.preventDefault();

//     var files = e.dataTransfer.files;

//     var file = files[0];

//     var reader = new FileReader();

//     reader.onload = function(e) {

//       var xml = e.target.result;

//       callback(xml);
//     };

//     reader.readAsText(file);
//   }

//   function handleDragOver(e) {
//     e.stopPropagation();
//     e.preventDefault();

//     e.dataTransfer.dropEffect = 'copy'; // Explicitly show this is a copy.
//   }

//   container.get(0).addEventListener('dragover', handleDragOver, false);
//   container.get(0).addEventListener('drop', handleFileSelect, false);
// }


// // file drag / drop ///////////////////////

// // check file api availability
// if (!window.FileList || !window.FileReader) {
//   window.alert(
//     'Looks like you use an older browser that does not support drag and drop. ' +
//     'Try using Chrome, Firefox or the Internet Explorer > 10.');
// } else {
//   registerFileDrop(container, openDiagram);
// }

// // bootstrap diagram functions

// $(function() {

//   $('#js-create-diagram').click(function(e) {
//     e.stopPropagation();
//     e.preventDefault();

//     createNewDiagram();
//   });

//   var downloadLink = $('#js-download-diagram');
//   var downloadSvgLink = $('#js-download-svg');

//   $('.buttons a').click(function(e) {
//     if (!$(this).is('.active')) {
//       e.preventDefault();
//       e.stopPropagation();
//     }
//   });

//   function setEncoded(link, name, data) {
//     var encodedData = encodeURIComponent(data);

//     if (data) {
//       link.addClass('active').attr({
//         'href': 'data:application/bpmn20-xml;charset=UTF-8,' + encodedData,
//         'download': name
//       });
//     } else {
//       link.removeClass('active');
//     }
//   }

//   var exportArtifacts = debounce(async function() {

//     try {

//       const { svg } = await bpmnModeler.saveSVG();

//       setEncoded(downloadSvgLink, 'diagram.svg', svg);
//     } catch (err) {

//       console.error('Error happened saving SVG: ', err);

//       setEncoded(downloadSvgLink, 'diagram.svg', null);
//     }

//     try {

//       const { xml } = await bpmnModeler.saveXML({ format: true });

//       setEncoded(downloadLink, 'diagram.bpmn', xml);
//     } catch (err) {

//       console.log('Error happened saving XML: ', err);

//       setEncoded(downloadLink, 'diagram.bpmn', null);
//     }
//   }, 500);

//   bpmnModeler.on('commandStack.changed', exportArtifacts);
// });

// "use client"
// import React, { useEffect, useRef, useState } from 'react';
// import BpmnModeler from 'bpmn-js/lib/Modeler';
// import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule } from 'bpmn-js-properties-panel';

// import 'bpmn-js/dist/assets/diagram-js.css';
// import 'bpmn-js/dist/assets/bpmn-js.css';
// import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css';
// import '@bpmn-io/properties-panel/assets/properties-panel.css';
// import './style.css';

// const BpmnEditor = () => {
//   const canvasRef = useRef(null);
//   const [modeler, setModeler] = useState(null);

//   useEffect(() => {
//     if (canvasRef.current) {
//       const modelerInstance = new BpmnModeler({
//         container: '#js-canvas',
//         propertiesPanel: {
//           parent: '#js-properties-panel'
//         },
//         additionalModules: [
//           BpmnPropertiesPanelModule,
//           BpmnPropertiesProviderModule
//         ]
//       });
  
//       setModeler(modelerInstance);
//       registerFileDrop(canvasRef.current, openDiagram);
  
//       return () => modelerInstance.destroy();
//     }
//   }, [canvasRef]);

//   async function openDiagram(xml) {
//     try {
//       await modeler.importXML(xml);
//     } catch (err) {
//       console.error('Failed to open diagram:', err);
//     }
//   }

//   function registerFileDrop(container, callback) {
//     const handleFileSelect = (event) => {
//       event.preventDefault();
//       const files = event.dataTransfer.files;
//       const reader = new FileReader();

//       reader.onload = (e) => callback(e.target.result);
//       reader.readAsText(files[0]);
//     };

//     container.addEventListener('dragover', (e) => e.preventDefault());
//     container.addEventListener('drop', handleFileSelect);
//   }

//   return (
//     <div>
//       <div ref={canvasRef} id="js-canvas" style={{ width: '100%', height: '500px', backgroundColor: 'white' }} />
//       <div id="js-properties-panel" />
//       {/* Additional UI components here */}
//     </div>
//   );
// };

// export default BpmnEditor;

// "use client"
// import React, { useEffect, useRef, useState } from 'react';
// import BpmnModeler from 'bpmn-js/lib/Modeler';
// import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule } from 'bpmn-js-properties-panel';
// import { debounce } from 'min-dash';

// import 'bpmn-js/dist/assets/diagram-js.css';
// import 'bpmn-js/dist/assets/bpmn-js.css';
// import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css';
// import '@bpmn-io/properties-panel/assets/properties-panel.css';
// import './style.css';  // Ensure this is a CSS module or correctly imported

// const BpmnEditor = () => {
//   const canvasRef = useRef(null);
//   const propertiesPanelRef = useRef(null);
//   const [modeler, setModeler] = useState(null);

//   useEffect(() => {
//     if (canvasRef.current){
//     const modelerInstance = new BpmnModeler({
//       container: canvasRef.current,
//       propertiesPanel: {
//         parent: propertiesPanelRef.current
//       },
//       additionalModules: [
//         BpmnPropertiesPanelModule,
//         BpmnPropertiesProviderModule
//       ]
//     });
//     const diagram=`<?xml version="1.0" encoding="UTF-8"?>
//     <bpmn2:definitions xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xsi:schemaLocation="http://www.omg.org/spec/BPMN/20100524/MODEL BPMN20.xsd" id="sample-diagram" targetNamespace="http://bpmn.io/schema/bpmn">
//       <bpmn2:process id="Process_1" isExecutable="false">
//         <bpmn2:startEvent id="StartEvent_1"/>
//       </bpmn2:process>
//       <bpmndi:BPMNDiagram id="BPMNDiagram_1">
//         <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1">
//           <bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="StartEvent_1">
//             <dc:Bounds height="36.0" width="36.0" x="412.0" y="240.0"/>
//           </bpmndi:BPMNShape>
//         </bpmndi:BPMNPlane>
//       </bpmndi:BPMNDiagram>
//     </bpmn2:definitions>`
    
//     setModeler(modelerInstance);
//     modelerInstance.importXML(diagram);  // Assume diagramXML is imported or defined
    
//     // Event listeners for drag and drop
//     const dropZone = canvasRef.current;
//     dropZone.addEventListener('dragover', (event) => event.preventDefault());
//     dropZone.addEventListener('drop', (event) => {
//       event.preventDefault();
//       const files = event.dataTransfer.files;
//       const reader = new FileReader();
//       reader.onload = async (e) => {
//         try {
//           await modelerInstance.importXML(e.target.result);
//         } catch (err) {
//           console.error('Error importing diagram:', err);
//         }
//       };
//       reader.readAsText(files[0]);
//     });
//   }
//     // return () => modelerInstance.destroy();
//   }, []);

//   return (
//     <div>
//       <div ref={canvasRef} style={{ width: '100%', height: '500px', backgroundColor: 'white' }}></div>
//       <div ref={propertiesPanelRef} style={{ width: '30%', float: 'right' }}></div>
//     </div>
//   );
// };

//  export default BpmnEditor;
// "use client"
// import React, { useEffect, useRef, useState } from 'react';
// import BpmnModeler from 'bpmn-js/lib/Modeler';
// import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule } from 'bpmn-js-properties-panel';
// import { debounce } from 'min-dash';

// // Styles for BPMN diagram and properties panel
// import 'bpmn-js/dist/assets/diagram-js.css';
// import 'bpmn-js/dist/assets/bpmn-js.css';
// import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css';
// import '@bpmn-io/properties-panel/assets/properties-panel.css';
// import './style.css';  // Ensure this is a CSS module or correctly imported

// const BpmnEditor = () => {
//   const canvasRef = useRef(null);
//   const propertiesPanelRef = useRef(null);
//   const [modeler, setModeler] = useState(null);

//   useEffect(() => {
//     if (canvasRef.current && propertiesPanelRef.current) {
//       const modelerInstance = new BpmnModeler({
//         container: canvasRef.current,
//         propertiesPanel: {
//           parent: propertiesPanelRef.current
//         },
//         additionalModules: [
//           BpmnPropertiesPanelModule,
//           BpmnPropertiesProviderModule
//         ]
//       });

      // const initialDiagram = `<?xml version="1.0" encoding="UTF-8"?>
      // <bpmn2:definitions xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xsi:schemaLocation="http://www.omg.org/spec/BPMN/20100524/MODEL BPMN20.xsd" id="sample-diagram" targetNamespace="http://bpmn.io/schema/bpmn">
      //   <bpmn2:process id="Process_1" isExecutable="false">
      //     <bpmn2:startEvent id="StartEvent_1"/>
      //   </bpmn2:process>
      //   <bpmndi:BPMNDiagram id="BPMNDiagram_1">
      //     <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1">
      //       <bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="StartEvent_1">
      //         <dc:Bounds height="36.0" width="36.0" x="412.0" y="240.0"/>
      //       </bpmndi:BPMNShape>
      //     </bpmndi:BPMNPlane>
      //   </bpmndi:BPMNDiagram>
      // </bpmn2:definitions>`;
    
//       setModeler(modelerInstance);
//       modelerInstance.importXML(initialDiagram);

//       // Event listeners for handling file drag-and-drop
//       const dropZone = canvasRef.current;
//       dropZone.addEventListener('dragover', (event) => event.preventDefault());
//       dropZone.addEventListener('drop', (event) => {
//         event.preventDefault();
//         const files = event.dataTransfer.files;
//         if (files.length) {
//           const reader = new FileReader();
//           reader.onload = async (e) => {
//             try {
//               await modelerInstance.importXML(e.target.result);
//             } catch (err) {
//               console.error('Error importing diagram:', err);
//             }
//           };
//           reader.readAsText(files[0]);
//         }
//       });

//       // Cleanup function to destroy modeler instance on component unmount
//       return () => modelerInstance.destroy();
//     }
//   }, [canvasRef, propertiesPanelRef]);  // Dependencies to ensure effect only runs once

//   return (
//     <div>
//       <div ref={canvasRef} style={{ width: '100%', height: '500px', backgroundColor: 'white' }}></div>
//       <div ref={propertiesPanelRef} style={{ width: '30%', float: 'right' }}></div>
//     </div>
//   );
// };

// export default BpmnEditor;

"use client"
import React, { useEffect, useRef, useState } from 'react';
import BpmnModeler from 'bpmn-js/lib/Modeler';

import { BpmnPropertiesPanelModule, BpmnPropertiesProviderModule,CamundaPlatformPropertiesProviderModule } from 'bpmn-js-properties-panel';
import CamundaBpmnModdle from "camunda-bpmn-moddle/resources/camunda.json";
// import 'bpmn-js/dist/assets/diagram-js.css';
// import 'bpmn-js/dist/assets/bpmn-js.css';
// import 'bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css';
// import '@bpmn-io/properties-panel/assets/properties-panel.css';
{/* <link rel="stylesheet" href="https://unpkg.com/@bpmn-io/properties-panel/dist/assets/properties-panel.css"></link> */}
import './style.css';
import "bpmn-js/dist/assets/diagram-js.css";
import "bpmn-js/dist/assets/bpmn-font/css/bpmn-embedded.css";
import "bpmn-js-properties-panel/dist/assets/properties-panel.css";



const BpmnEditor = () => {
  const canvasRef = useRef(null);
  const propertiesPanelRef = useRef(null);
  const [modeler, setModeler] = useState(null);




  useEffect(() => {

    if (!canvasRef.current || !propertiesPanelRef.current) {
      console.log('Refs not initialized');
      return; // Exit the effect if refs are not ready
    }
    const modelerInstance = new BpmnModeler({
      container: canvasRef.current,
      propertiesPanel: {
        parent: propertiesPanelRef.current
      },
      moddleExtensions: {
        camunda: CamundaBpmnModdle,
      },
      additionalModules: [
        // customPropertiesProviderModule,
        BpmnPropertiesPanelModule,
        BpmnPropertiesProviderModule,
        CamundaPlatformPropertiesProviderModule,
        // lintModule,
      ],
    });

    // Importing initial XML diagram
   const initialDiagram = `<?xml version="1.0" encoding="UTF-8"?>
    <bpmn2:definitions xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:bpmn2="http://www.omg.org/spec/BPMN/20100524/MODEL" xmlns:bpmndi="http://www.omg.org/spec/BPMN/20100524/DI" xmlns:dc="http://www.omg.org/spec/DD/20100524/DC" xmlns:di="http://www.omg.org/spec/DD/20100524/DI" xsi:schemaLocation="http://www.omg.org/spec/BPMN/20100524/MODEL BPMN20.xsd" id="sample-diagram" targetNamespace="http://bpmn.io/schema/bpmn">
      <bpmn2:process id="Process_1" isExecutable="false">
        <bpmn2:startEvent id="StartEvent_1"/>
      </bpmn2:process>
      <bpmndi:BPMNDiagram id="BPMNDiagram_1">
        <bpmndi:BPMNPlane id="BPMNPlane_1" bpmnElement="Process_1">
          <bpmndi:BPMNShape id="_BPMNShape_StartEvent_2" bpmnElement="StartEvent_1">
            <dc:Bounds height="36.0" width="36.0" x="412.0" y="240.0"/>
          </bpmndi:BPMNShape>
        </bpmndi:BPMNPlane>
      </bpmndi:BPMNDiagram>
    </bpmn2:definitions>`;; // Your BPMN XML string

    modelerInstance.importXML(initialDiagram).catch(err => console.error('Error importing default diagram:', err));

    // Setup file drop listener
    const handleFileDrop = async (event) => {
      event.preventDefault();
      const files = event.dataTransfer.files;
      if (files.length > 0) {
        const file = files[0];
        const reader = new FileReader();
        reader.onload = async (e) => {
          try {
            await modelerInstance.importXML(e.target.result);
          } catch (err) {
            console.error('Error importing diagram:', err);
          }
        };
        reader.readAsText(file);
      }
    };

    const dropZone = canvasRef.current;
    dropZone.addEventListener('dragover', (event) => event.preventDefault());
    dropZone.addEventListener('drop', handleFileDrop);

    setModeler(modelerInstance);

    // Clean up on component unmount
    return () => {
      dropZone.removeEventListener('dragover', (event) => event.preventDefault());
      dropZone.removeEventListener('drop', handleFileDrop);
      modelerInstance.destroy();
    };
  }, []);

  return (
    <div>
      <div ref={canvasRef} style={{ width: '100%', height: '500px', backgroundColor: 'white' }}></div>
      <div ref={propertiesPanelRef} style={{ width: '30%', float: 'right' }}></div>
    </div>
  );
};

export default BpmnEditor;